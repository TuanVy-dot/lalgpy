class DimensionsError(Exception):
    """
    Dimensional related error
    """
    pass
